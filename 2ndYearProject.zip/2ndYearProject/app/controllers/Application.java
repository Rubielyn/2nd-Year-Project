package controllers;

import play.*;
import play.mvc.*;
import play.data.*;
import play.data.Form.*;
import play.mvc.Http.Context;

import views.html.*;
import models.products.*;

// Import required classes
import java.util.ArrayList;
import java.util.List;

// Import models
import models.*;

import controllers.security.*;

public class Application extends Controller {

	public User getCurrentUser() {
		User u = User.getLoggedIn(session().get("email"));
		return u;
	}
	//Customer Login 
	public Result login() {
	return ok(login.render(Form.form(Login.class), Customer.getLoggedIn(session().get("email"))));
	}
	//Add as a new customer if new
  public Result addCustomer() 
  {
	  Form<Customer> addRegisterForm = Form.form(Customer.class);
	  
	  return ok(addCustomer.render(addRegisterForm, getCurrentUser()));
  }
  //submit customer from
  public Result addCustomerSubmit() {
	  
	  Form<Customer> newRegisterForm = Form.form(Customer.class).bindFromRequest();
		
		if(newRegisterForm.hasErrors()) {
			return badRequest(addCustomer.render(newRegisterForm, getCurrentUser()));
		}
		
		newRegisterForm.get().save();
		
		flash("success", "Register" + newRegisterForm.get().name + "has been created");

  	  return redirect(routes.Application.login());
  	}
  		//register new Customer then log in
  	 public Result register() {
	 
		 List<Customer> users = Customer.findAllCus();
	
		return ok(register.render(users,Customer.getLoggedIn(session().get("email"))));
    }
	
  
}
