package controllers;

import play.*;
import play.mvc.*;
import play.data.*;
import play.data.Form.*;
import play.mvc.Http.Context;

import play.mvc.Http.*;
import play.mvc.Http.MultipartFormData.FilePart;
import java.io.*;
import java.io.File;
import javax.activation.MimetypesFileTypeMap;
import play.Logger;

// File upload and image editing dependencies
import org.im4java.process.ProcessStarter;
import org.im4java.core.ConvertCmd;
import org.im4java.core.IMOperation;

import views.html.productAdmin.*;

// Import required classes
import java.util.ArrayList;
import java.util.List;
// Import models
import models.*;
import models.products.*;

import controllers.security.*;

/* - Docs -
http://superuser.com/questions/163818/how-to-install-rmagick-on-ubuntu-10-04
http://im4java.sourceforge.net/
*/

// Authenticate user
@Security.Authenticated(Secured.class)
// Authorise user (check if admin)
@With(CheckAdmin.class)

public class AdminProductCtrl extends Controller {
	
    // Get a user - if logged in email will be set in the session
	private User getCurrentUser() {
		User u = User.getLoggedIn(session().get("email"));
		return u;
	}
    //Admin Home page
    public Result index() {
        return redirect(routes.AdminProductCtrl.listProducts(0,""));
    }
		//Admin User manual
   public Result userManualAdmin() {
        return ok(userManualAdmin.render(User.getLoggedIn(session().get("email"))));
    }

		// Get a list of products
    // If cat parameter is 0 then return all products
    // Otherwise return products for a category (by id)
		// In both cases products will be searched using the filter value 
    public Result listProducts(Long cat, String filter) {
        // Get list of all categories in ascending order
        List<Category> categories = Category.find.where().orderBy("name asc").findList();
        // Instantiate products, an Array list of products			
        List<Product> products = new ArrayList<Product>();
    
        if (cat == 0) {
            // Get the list of ALL products with filter
            products = Product.findAll(filter);
        }
        else {
            // Get products for the selected category and filter (search field)
            products = Product.findFilter(cat, filter);
        }
        // Render the list products view, passwing parameters
        // categories and products lists
        // current user - if one is logged in
        return ok(listProducts.render(categories, products, cat, filter, getCurrentUser()));
    }

    // Load the add product view
    // Display an empty form in the view
    public Result addProduct() {   
        // Instantiate a form object based on the Product class
        Form<Product> addProductForm = Form.form(Product.class);
        // Render the Add Product View, passing the form object
        return ok(addProduct.render(addProductForm, getCurrentUser()));
    }

    // Handle the form data when a new product is submitted
    public Result addProductSubmit() {

        String saveImageMsg;

        // Create a product form object (to hold submitted data)
        // 'Bind' the object to the submitted form (this copies the filled form)
        Form<Product> newProductForm = Form.form(Product.class).bindFromRequest();	

        // Check for errors (based on Product class annotations)	
        if(newProductForm.hasErrors()) {
            // Display the form again
            return badRequest(addProduct.render(newProductForm, getCurrentUser()));
        }
        // Save the Product using Ebean (remember Product extends Model)
        newProductForm.get().save();

        // Get image data
        MultipartFormData data = request().body().asMultipartFormData();
        FilePart image = data.getFile("upload");
        
        // Save the image file
        saveImageMsg = saveFile(newProductForm.get().id, image);

        // Set a sucess message in temporary flash
        flash("success", "Product " + newProductForm.get().name + " has been created" + " " + saveImageMsg);
            
        // Redirect to the admin home
        return redirect(routes.AdminProductCtrl.index());
    }
        
    // Update a product by ID
    // called when edit button is pressed
    public Result updateProduct(Long id) {

        // Create a form based on the Product class
        // Fill the form with product object matching id
        // Use the finder to find the object by ID in the DB
        Form<Product> productForm = Form.form(Product.class).fill(
                    Product.find.byId(id)
        );
        // Render the updateProduct view
        // pass the id and form as parameters
        return ok(updateProduct.render(id, productForm, getCurrentUser()));		
    }


    // Handle the form data when an updated product is submitted
    public Result updateProductSubmit(Long id) {

        String saveImageMsg;

        // Create a product form object (to hold submitted data)
        // 'Bind' the object to the submitted form (this copies the filled form)
        Form<Product> updateProductForm = Form.form(Product.class).bindFromRequest();	

        // Check for errors (based on Product class annotations)	
        if(updateProductForm.hasErrors()) {
            // Display the form again
            return badRequest(updateProduct.render(id, updateProductForm, getCurrentUser()));
        }
        
        // Update the Product (using its ID to select the existing object))
        Product p = updateProductForm.get();
        p.id = id;
        p.update();

        // Get image data
        MultipartFormData data = request().body().asMultipartFormData();
        FilePart image = data.getFile("upload");

        saveImageMsg = saveFile(p.id, image);

        // Add a success message to the flash session
        flash("success", "Product " + updateProductForm.get().name + " has been updates" + " " + saveImageMsg);
            
        // Return to admin home
        return redirect(routes.AdminProductCtrl.index());
    }


    // Delete Product
    public Result deleteProduct(Long id) {
        // Call delete method
        Product.find.ref(id).delete();
        // Add message to flash session 
        flash("success", "Product has been deleted");
        // Redirect home
        return redirect(routes.AdminProductCtrl.index());
    }
    
    // Save an image file
    public String saveFile(Long id, FilePart image) {
        if (image != null) {
            // Get mimetype from image
            String mimeType = image.getContentType();
            // Check if uploaded file is an image
            if (mimeType.startsWith("image/")) {
                // Create file from uploaded image
                File file = image.getFile();
                // create ImageMagick command instance
                ConvertCmd cmd = new ConvertCmd();
                // create the operation, add images and operators/options
                IMOperation op = new IMOperation();
                // Get the uploaded image file
                op.addImage(file.getAbsolutePath());
                // Resize using height and width constraints
                op.resize(300,200);
                // Save the  image
                op.addImage("public/images/productImages/" + id + ".jpg");
                // thumbnail
                IMOperation thumb = new IMOperation();
                // Get the uploaded image file
                thumb.addImage(file.getAbsolutePath());
                thumb.thumbnail(60);
                // Save the  image
                thumb.addImage("public/images/productImages/thumbnails/" + id + ".jpg");
                // execute the operation
                try{
                    cmd.run(op);
                    cmd.run(thumb);
                }
                catch(Exception e){
                    e.printStackTrace();
                }				
                return " and image saved";
            }
        }
        return "image file missing";	
    }
}
