package controllers;

import play.*;
import play.mvc.*;
import play.data.*;
import play.data.Form.*;
import play.mvc.Http.Context;

import java.util.ArrayList;
import java.util.List;

import views.html.*;

// Import models
import models.*;
import models.products.*;

// Import security controllers
import controllers.security.*;

public class ProductCtrl extends Controller {

    // Get a user - if logged in email will be set in the session
		public User getCurrentUser() {
		User u = User.getLoggedIn(session().get("email"));
		return u;
		}
    	//Customer Home page
    public Result index() {
		return ok(index.render(User.getLoggedIn(session().get("email"))));
    }
	
	 	public Result about() {
        return ok(about.render(User.getLoggedIn(session().get("email"))));
    }
	
	    public Result product() {
        return redirect(routes.ProductCtrl.listProducts(0,""));
    }
	
    	public Result contact() {
        return ok(contact.render(User.getLoggedIn(session().get("email"))));
    }
				
			public Result contactResponse() {
        return ok(contactResponse.render(User.getLoggedIn(session().get("email"))));
    }
				//Customer user manual
			public Result userManual() {
        return ok(userManual.render(User.getLoggedIn(session().get("email"))));
    }

		// Get a list of products
    // If cat parameter is 0 then return all products
    // Otherwise return products for a category (by id)
		// In both cases products will be searched using the filter value 
    public Result listProducts(Long cat, String filter) {
        // Get list of all categories in ascending order
        List<Category> categories = Category.find.where().orderBy("name asc").findList();
        // Instantiate products, an Array list of products			
        List<Product> products = new ArrayList<Product>();
    
        if (cat == 0) {
            // Get the list of ALL products with filter
            products = Product.findAll(filter);
        }
        else {
            // Get products for the selected category and filter (search field)
            products = Product.findFilter(cat, filter);
        }
        // Render the list products view, passwing parameters
        // categories and products lists
        // current user - if one is logged in
        return ok(listProducts.render(categories, products, cat, filter, getCurrentUser()));
    }
	
}
